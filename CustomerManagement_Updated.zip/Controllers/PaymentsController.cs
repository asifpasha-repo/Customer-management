using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

public class PaymentsController : Controller
{
    private readonly ApplicationDbContext _context;

    public PaymentsController(ApplicationDbContext context)
    {
        _context = context;
    }

    private async Task UpdateOrderPaymentStatus(int customerId)
    {
        var orders = await _context.Orders.Where(o => o.CustomerID == customerId).ToListAsync();
        var totalPaid = await _context.Payments.Where(p => p.CustomerID == customerId).SumAsync(p => p.Amount);

        foreach (var order in orders)
        {
            if (totalPaid >= order.TotalAmount)
                order.Status = "Paid";
            else if (totalPaid > 0)
                order.Status = "Partially Paid";
            else
                order.Status = "Pending";
        }

        await _context.SaveChangesAsync();
    }

    [HttpPost]
    public async Task<IActionResult> AddPayment(Payment payment)
    {
        if (ModelState.IsValid)
        {
            _context.Payments.Add(payment);
            await _context.SaveChangesAsync();
            await UpdateOrderPaymentStatus(payment.CustomerID);
            return RedirectToAction("Index");
        }
        return View(payment);
    }

    [HttpPost]
    public async Task<IActionResult> EditPayment(Payment payment)
    {
        if (ModelState.IsValid)
        {
            _context.Payments.Update(payment);
            await _context.SaveChangesAsync();
            await UpdateOrderPaymentStatus(payment.CustomerID);
            return RedirectToAction("Index");
        }
        return View(payment);
    }

    [HttpPost]
    public async Task<IActionResult> DeletePayment(int id)
    {
        var payment = await _context.Payments.FindAsync(id);
        if (payment != null)
        {
            int customerId = payment.CustomerID;
            _context.Payments.Remove(payment);
            await _context.SaveChangesAsync();
            await UpdateOrderPaymentStatus(customerId);
        }
        return RedirectToAction("Index");
    }
}