using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

public class CustomersController : Controller
{
    private readonly ApplicationDbContext _context;

    public CustomersController(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<IActionResult> Index()
    {
        var customers = await _context.Customers.Include(c => c.Orders).Include(c => c.Payments).ToListAsync();
        return View(customers);
    }

    [HttpGet]
    public async Task<IActionResult> GetCustomerDetails(int id)
    {
        var customer = await _context.Customers
            .Include(c => c.Orders)
            .Include(c => c.Payments)
            .FirstOrDefaultAsync(c => c.CustomerID == id);

        if (customer == null) return NotFound();

        var result = new
        {
            Orders = customer.Orders.Select(o => new { o.OrderID, OrderDate = o.OrderDate.ToShortDateString(), o.TotalAmount, o.Status }),
            Payments = customer.Payments.Select(p => new { p.PaymentID, PaymentDate = p.PaymentDate.ToShortDateString(), p.Amount, p.PaymentMethod })
        };

        return Json(result);
    }
}