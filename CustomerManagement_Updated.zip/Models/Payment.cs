using System;

public class Payment
{
    public int PaymentID { get; set; }
    public int CustomerID { get; set; }
    public DateTime PaymentDate { get; set; }
    public decimal Amount { get; set; }
    public string PaymentMethod { get; set; }
    public Customer Customer { get; set; }
}