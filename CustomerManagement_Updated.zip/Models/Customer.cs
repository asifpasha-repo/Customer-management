using System.Collections.Generic;

public class Customer
{
    public int CustomerID { get; set; }
    public string Name { get; set; }
    public List<Order> Orders { get; set; } = new List<Order>();
    public List<Payment> Payments { get; set; } = new List<Payment>();
}